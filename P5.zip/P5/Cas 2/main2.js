//Thème 2 sélectionné d'origine
 var choix = 2;
//Récuperation de la valeur en fonction du CLICK du thème pour l'utilisateur
     function modifchoix(pchoix) {
      choix = pchoix;
      console.log (pchoix)
    };

//Creation des citations
    function choixCitation () {
      var citationsDebut, citationsMilieu, citationsFin;
      var randomDebut, randomMilieu, randomFin;
//Création des citations en fonction du thème choisie
    if (choix === 1){
      citationsDebut = ["La vie", "Le monde", "Le bonheur"];
      citationsMilieu = [" est un mystère qu'il faut vivre", " est un ami qui ne trahit jamais", " c'est comme une bicyclette"];
      citationsFin = [" car nous ne penserons jamais de la même façon"," il faut avancer pour ne pas perdre l'équilibre", " pour les connaître, il faut les aimer"];
    } else if (choix === 2){
      citationsDebut = ["Vu", "Quelle que soit", "Avec"];
      citationsMilieu = [" la situation actuelle", " la crise de cette fin de siècle", " la conjoncture d'aujourd'hui"];
      citationsFin = [" il faut étudier toutes les solutions"," il serait bon d'imaginer le meilleur", " il faut voir la vie en rose"];
    }
//Selection aléatoire des differentes parties de la citation
      randomDebut = citationsDebut[Math.floor(Math.random() * citationsDebut.length)];
      randomMilieu = citationsMilieu[Math.floor(Math.random() * citationsMilieu.length)];
      randomFin = citationsFin[Math.floor(Math.random() * citationsFin.length)];
//Création de la citation
      var resultat = randomDebut + randomMilieu + randomFin;
//Affichage des citations dans html
      var contenuDiv = document.getElementById('citation').innerHTML;
      document.getElementById('citation').innerHTML = contenuDiv + '<br>' + resultat + '<br>';
//Affichage des citations dans la console
      console.log (resultat);
    };

//Action du bonton générer
    function generer() {
      reset();
      var nombre = document.getElementById("nbrecitations").value;
      if (nombre > 0 && nombre <= 5) {
        for (var i = 1; i <= nombre; i++) {
      choixCitation();
        }
      }
    }
//Action du bonton réinitialiser
    function reset () {
      document.getElementById('citation').innerHTML = "";
    }






