
 // Creation de la citation
    function choixCitation () {

        var citationfirstpart = ["Autrefois", "Il fut un temps", "Il y a quelques années"];
        var citationsecondpart = [" les animaux", " les humains", " les vegetaux"];
        var citationthirdpart = [" reflechissaient !", " prenaient !", " repartaient !"];
        //Selection aléatoire des differentes parties de la citation
        var randomFirstPart = citationfirstpart[Math.floor(Math.random() * citationfirstpart.length)];
        var randomSecondPart = citationsecondpart[Math.floor(Math.random() * citationsecondpart.length)];
        var randomThirdPart = citationthirdpart[Math.floor(Math.random() * citationthirdpart.length)];
        //Création de la citation
        var resultat = randomFirstPart + randomSecondPart + randomThirdPart;
        //Affichage de la citation en html
        var contenuDiv = document.getElementById('citation').innerHTML;
        document.getElementById('citation').innerHTML = resultat;
        //Affichage de la citation dans la console
        console.log (resultat);
    };

// Action du bonton générer
    function generer() {
       choixCitation();
    };





